# Security Policy

## Supported Versions

| Version  | Supported          |
| -------- | ------------------ |
| 0.20.x   | :white_check_mark: |
| < 0.20.x | :x:                |

## Reporting a Vulnerability

Please report security issues by e-mail to jelmer@jelmer.uk, ideally PGP
encrypted to the key at <https://jelmer.uk/D729A457.asc>
